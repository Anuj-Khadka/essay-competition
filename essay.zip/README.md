A small web based application which testes some of the most important aspects during online test i.e. copy-paste, and tab switches or leaving the exam paper and navigating somewhere else
